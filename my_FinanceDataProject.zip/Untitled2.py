import json
import os
from datetime import datetime

FILE_NAME = "finance_data.json"

def load_data():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, "r") as file:
            return json.load(file)
    return {"transactions": []}

def save_data(data):
    with open(FILE_NAME, "w") as file:
        json.dump(data, file, indent=4)

def add_transaction(data):
    print("\n--- Add Transaction ---")
    transaction_type = input("Type (income/expense): ").lower()

    if transaction_type not in ["income", "expense"]:
        print("Invalid type.")
        return

    try:
        amount = float(input("Amount: R"))
    except ValueError:
        print("Invalid amount.")
        return

    category = input("Category: ")
    description = input("Description: ")

    transaction = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": transaction_type,
        "amount": amount,
        "category": category,
        "description": description
    }

    data["transactions"].append(transaction)
    save_data(data)
    print("Transaction added successfully.")

def view_transactions(data):
    print("\n--- Transactions ---")

    if not data["transactions"]:
        print("No transactions found.")
        return

    for i, t in enumerate(data["transactions"], start=1):
        print(f"""
{i}. Date: {t['date']}
   Type: {t['type']}
   Amount: R{t['amount']:.2f}
   Category: {t['category']}
   Description: {t['description']}
""")

def financial_summary(data):
    income = sum(
        t["amount"] for t in data["transactions"]
        if t["type"] == "income"
    )

    expenses = sum(
        t["amount"] for t in data["transactions"]
        if t["type"] == "expense"
    )

    balance = income - expenses

    print("\n--- Financial Summary ---")
    print(f"Total Income   : R{income:.2f}")
    print(f"Total Expenses : R{expenses:.2f}")
    print(f"Current Balance: R{balance:.2f}")

def category_report(data):
    print("\n--- Expense Report By Category ---")

    categories = {}

    for t in data["transactions"]:
        if t["type"] == "expense":
            categories[t["category"]] = (
                categories.get(t["category"], 0)
                + t["amount"]
            )

    if not categories:
        print("No expenses recorded.")
        return

    for category, total in sorted(categories.items(),
                                  key=lambda x: x[1],
                                  reverse=True):
        print(f"{category}: R{total:.2f}")

def set_budget(data):
    try:
        budget = float(input("Enter monthly budget: R"))
        data["budget"] = budget
        save_data(data)
        print("Budget saved.")
    except ValueError:
        print("Invalid budget amount.")

def check_budget(data):
    budget = data.get("budget")

    if not budget:
        print("No budget set.")
        return

    expenses = sum(
        t["amount"]
        for t in data["transactions"]
        if t["type"] == "expense"
    )

    print(f"\nBudget: R{budget:.2f}")
    print(f"Spent : R{expenses:.2f}")

    if expenses > budget:
        print("⚠ WARNING: Budget exceeded!")
    else:
        remaining = budget - expenses
        print(f"Remaining: R{remaining:.2f}")

def main():
    data = load_data()

    while True:
        print("""
==========================
 PERSONAL FINANCE TRACKER
==========================
1. Add Transaction
2. View Transactions
3. Financial Summary
4. Expense Report
5. Set Budget
6. Check Budget
7. Exit
""")

        choice = input("Select option: ")

        if choice == "1":
            add_transaction(data)
        elif choice == "2":
            view_transactions(data)
        elif choice == "3":
            financial_summary(data)
        elif choice == "4":
            category_report(data)
        elif choice == "5":
            set_budget(data)
        elif choice == "6":
            check_budget(data)
        elif choice == "7":
            print("Goodbye!")
            break
        else:
            print("Invalid option.")

if __name__ == "__main__":
    main()